package vetClinic;

import java.util.ArrayList;
import java.util.List;

public class Clinic {

    private int capacity;
    private List<Pet> data = new ArrayList<>();


    public Clinic(int capacity) {
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public void add(Pet pet) {
        if (this.data.size() < this.capacity) {
            this.data.add(pet);
        }
    }

    public boolean remove(String name) {
        return data.removeIf(e -> e.getName().equals(name));
    }


    /*public Pet getPet(String name, String owner) {
        return data.stream().filter(e -> e.getName().equals(name) && e.getOwner().equals(owner)).findFirst().orElse(null);
    }*/

    public Pet getPet(String name, String owner) {
        for (Pet pet : data) {
            if (pet.getName().equals(name) && pet.getOwner().equals(owner)) {
                return pet;
            }
        }
        return null;
    }
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append("The clinic has the following patients:");
        for (Pet pet : data) {
            sb.append(System.lineSeparator());
            sb.append(pet.getName() + " " + pet.getOwner());
        }
        return sb.toString();
    }

    public Pet getOldestPet() {
        return this.data.stream().max((e1, e2) -> Integer.compare(e1.getAge(), e2.getAge())).get();
    }

    public int getCount() {
        return data.size();
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public List<Pet> getPet() {
        return data;
    }

    public void setPet(List<Pet> pet) {
        this.data = pet;
    }
}
